Popup-Chat
==========

Popup for the chat on Grepolis
