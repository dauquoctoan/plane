// ==UserScript==
// @name        Popup Chat
// @namespace   ssm
// @description Instead of an in screen chat, pop it allllll up!
// @include     http://*.grepolis.*/game*
// @version     0.3.4
// @grant       none
// @downloadURL https://github.com/breakerh/Popup-Chat/raw/master/Popup_chat.user.js
// @updateURL https://github.com/breakerh/Popup-Chat/raw/master/Popup_chat.meta.js
// ==/UserScript==